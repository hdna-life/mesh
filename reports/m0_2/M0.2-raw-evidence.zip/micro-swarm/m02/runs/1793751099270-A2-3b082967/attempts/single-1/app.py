import sqlite3
from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///inventory.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sku = db.Column(db.String(16), unique=True, nullable=False)
    name = db.Column(db.String(80), nullable=False, unique=True)
    stock = db.Column(db.Integer, nullable=False, default=1000)

class Reservation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    request_key = db.Column(db.String(64), nullable=False)
    status = db.Column(db.String(20), nullable=False, default='active')

@app.route('/products', methods=['GET'])
def get_products():
    conn = db.engine.connect()
    cur = conn.cursor()
    cur.execute("SELECT * FROM products")
    products = cur.fetchall()
    return jsonify([dict(product) for product in products])

@app.route('/products/<int:product_id>', methods=['GET'])
def get_product(product_id):
    conn = db.engine.connect()
    cur = conn.cursor()
    cur.execute("SELECT * FROM products WHERE id = ?", (product_id,))
    product = cur.fetchone()
    if product is None:
        return jsonify({"error": "Product not found"}), 404
    return jsonify(dict(product))

@app.route('/reservations', methods=['POST'])
def create_reservation():
    data = request.get_json()
    if not data:
        return jsonify({"error": "Missing product"}), 400
    product = Product.query.get(data['product_id'])
    if product is None:
        return jsonify({"error": "Product not found"}), 404
    if not data['quantity'] or not data['request_key']:
        return jsonify({"error": "Missing quantity or request_key"}), 400
    if not isinstance(data['quantity'], int) or data['quantity'] < 1 or data['quantity'] > 100:
        return jsonify({"error": "Quantity must be between 1 and 100"}), 400
    product.stock -= data['quantity']
    reservation = Reservation(product_id=data['product_id'], quantity=data['quantity'], request_key=data['request_key'])
    db.session.add(reservation)
    db.session.commit()
    return jsonify({"id": reservation.id, "sku": reservation.product_id, "name": reservation.product.name, "stock": reservation.stock}), 201

@app.route('/reservations/<int:reservation_id>/cancel', methods=['POST'])
def cancel_reservation(reservation_id):
    reservation = Reservation.query.get(reservation_id)
    if reservation is None:
        return jsonify({"error": "Reservation not found"}), 404
    if reservation.status != 'active':
        return jsonify({"error": "Reservation is not active"}), 409
    reservation.status = 'cancelled'
    db.session.commit()
    return jsonify({"id": reservation.id, "sku": reservation.product_id, "name": reservation.product.name, "stock": reservation.product.stock}), 200

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(host='127.0.0.1', port=5000)
