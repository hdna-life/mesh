import os
import sqlite3
from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///inventory.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SQLALCHEMY_ECHO"] = False

db = SQLAlchemy(app)

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sku = db.Column(db.String(16), unique=True, nullable=False)
    name = db.Column(db.String(80), nullable=False)
    stock = db.Column(db.Integer, nullable=False, default=1000)

class Reservation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    request_key = db.Column(db.String(64), nullable=False)
    status = db.Column(db.String(10), nullable=False, default="active")

    def __repr__(self):
        return f"Reservation(id={self.id}, product_id={self.product_id}, quantity={self.quantity}, request_key='{self.request_key}', status='{self.status}')"

@app.route("/products", methods=["GET"])
def get_products():
    products = Product.query.all()
    return jsonify([product.to_dict() for product in products])

@app.route("/products/<int:id>", methods=["GET"])
def get_product(id):
    product = Product.query.get(id)
    if product is None:
        return jsonify({"error": "Product not found"}), 404
    return jsonify(product.to_dict())

@app.route("/reservations", methods=["POST"])
def create_reservation():
    data = request.json
    if not data:
        return jsonify({"error": "Missing request body"}), 400
    product_id = data["product_id"]
    quantity = data["quantity"]
    if not isinstance(quantity, int) or quantity < 1:
        return jsonify({"error": "Invalid quantity"}), 400
    product = Product.query.get(product_id)
    if product is None:
        return jsonify({"error": "Product not found"}), 404
    if product.stock < quantity:
        return jsonify({"error": "Insufficient stock"}), 409
    reservation = Reservation(product_id=product_id, quantity=quantity, request_key=data["request_key"])
    db.session.add(reservation)
    db.session.commit()
    return jsonify(reservation.to_dict()), 201

@app.route("/reservations/<int:id>/cancel", methods=["POST"])
def cancel_reservation(id):
    reservation = Reservation.query.get(id)
    if reservation is None:
        return jsonify({"error": "Reservation not found"}), 404
    if reservation.status == "active":
        reservation.status = "cancelled"
        db.session.commit()
        return jsonify({"message": "Reservation cancelled"}), 200
    return jsonify({"error": "Reservation is not active"}), 409

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(host="127.0.0.1", port=os.environ.get("PORT", 5000), debug=False)
