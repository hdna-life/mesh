import os
import sqlite3
from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///inventory.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SQLALCHEMY_ECHO"] = False

db = SQLAlchemy(app)

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sku = db.Column(db.String(16), unique=True, nullable=False)
    name = db.Column(db.String(80), nullable=False)
    stock = db.Column(db.Integer, nullable=False, default=1000)

class Reservation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    request_key = db.Column(db.String(64), nullable=False)
    status = db.Column(db.String(10), nullable=False, default="active")

    def __repr__(self):
        return f"Reservation(id={self.id}, product_id={self.product_id}, quantity={self.quantity}, request_key='{self.request_key}', status='{self.status}')"

def create_tables():
    db.create_all()

def get_products():
    return Product.query.all()

def get_product(id):
    return Product.query.get(id)

def get_reservations():
    return Reservation.query.all()

def get_reservation(id):
    return Reservation.query.get(id)

def create_reservation(product_id, quantity, request_key):
    product = get_product(product_id)
    if product is None:
        return jsonify({"error": "Product not found"}), 404
    if not request_key:
        return jsonify({"error": "Missing request key"}), 400
    if not request_key.isalnum():
        return jsonify({"error": "Invalid request key"}), 400
    if not 1 <= quantity <= 100:
        return jsonify({"error": "Quantity must be between 1 and 100"}), 400
    if product.stock < 0:
        return jsonify({"error": "Stock cannot be negative"}), 409
    new_quantity = product.stock - quantity
    if new_quantity < 0:
        return jsonify({"error": "Cannot decrease stock"}), 409
    product.stock = new_quantity
    db.session.commit()
    return jsonify({"id": product.id, "quantity": quantity, "request_key": request_key, "status": "active"})

def cancel_reservation(id):
    reservation = get_reservation(id)
    if reservation is None:
        return jsonify({"error": "Reservation not found"}), 404
    if reservation.status != "active":
        return jsonify({"error": "Reservation is not active"}), 409
    db.session.delete(reservation)
    db.session.commit()
    return jsonify({"id": id, "status": "cancelled"})

@app.route("/products", methods=["GET"])
def get_products():
    return jsonify([{"id": product.id, "sku": product.sku, "name": product.name, "stock": product.stock} for product in get_products()])

@app.route("/products/<int:id>", methods=["GET"])
def get_product(id):
    return jsonify({"id": id, "sku": get_product(id).sku, "name": get_product(id).name, "stock": get_product(id).stock})

@app.route("/reservations", methods=["GET"])
def get_reservations():
    return jsonify([{"id": reservation.id, "product_id": reservation.product_id, "quantity": reservation.quantity, "request_key": reservation.request_key, "status": reservation.status} for reservation in get_reservations()])

@app.route("/reservations/<int:id>", methods=["GET"])
def get_reservation(id):
    return jsonify({"id": id, "product_id": get_reservation(id).product_id, "quantity": get_reservation(id).quantity, "request_key": get_reservation(id).request_key, "status": get_reservation(id).status})

@app.route("/reservations", methods=["POST"])
def create_reservation():
    data = request.json
    if not data:
        return jsonify({"error": "Missing request body"}), 400
    product_id = data["product_id"]
    quantity = data["quantity"]
    request_key = data["request_key"]
    if not product_id or not quantity or not request_key:
        return jsonify({"error": "Missing required fields"}), 400
    product = get_product(product_id)
    if product is None:
        return jsonify({"error": "Product not found"}), 404
    if not request_key.isalnum():
        return jsonify({"error": "Invalid request key"}), 400
    if not 1 <= quantity <= 100:
        return jsonify({"error": "Quantity must be between 1 and 100"}), 400
    if product.stock < 0:
        return jsonify({"error": "Stock cannot be negative"}), 409
    new_quantity = product.stock - quantity
    if new_quantity < 0:
        return jsonify({"error": "Cannot decrease stock"}), 409
    product.stock = new_quantity
    db.session.commit()
    return jsonify({"id": product.id, "quantity": quantity, "request_key": request_key, "status": "active"})

@app.route("/reservations/<int:id>/cancel", methods=["POST"])
def cancel_reservation(id):
    return cancel_reservation(id)

if __name__ == "__main__":
    create_tables()
    app.run(host="127.0.0.1", port=os.environ.get("PORT", 5000), debug=False)
