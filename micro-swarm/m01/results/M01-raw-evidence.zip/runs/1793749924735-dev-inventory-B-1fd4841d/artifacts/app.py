import os
import sqlite3
from flask import Flask, request, jsonify

app = Flask(__name__)

DATABASE_PATH = os.environ.get('DATABASE_PATH')
if not os.path.exists(DATABASE_PATH):
    open(DATABASE_PATH, 'w').close()

conn = sqlite3.connect(DATABASE_PATH)
cursor = conn.cursor()

cursor.execute('''CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY,
    sku TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    stock INTEGER NOT NULL
    );''')
cursor.execute('''CREATE TABLE IF NOT EXISTS reservations (
    id INTEGER PRIMARY KEY,
    product_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL,
    request_key TEXT NOT NULL,
    status TEXT NOT NULL,
    FOREIGN KEY (product_id) REFERENCES products (id)
    );''')

def get_products():
    cursor.execute('SELECT * FROM products ORDER BY id ASC')
    return [dict(row) for row in cursor.fetchall()]

def get_product(id):
    cursor.execute('SELECT * FROM products WHERE id = ?', (id,))
    return dict(cursor.fetchone())

def get_reservations():
    cursor.execute('SELECT * FROM reservations ORDER BY id ASC')
    return [dict(row) for row in cursor.fetchall()]

def get_reservation(id):
    cursor.execute('SELECT * FROM reservations WHERE id = ?', (id,))
    return dict(cursor.fetchone())

def create_reservation():
    data = request.get_json()
    if not data or not all(key in data for key in ['sku', 'name', 'stock']):
        return jsonify({'error': 'Missing required fields'}, 400)
    if not data['sku'].isalnum():
        return jsonify({'error': 'Invalid SKU'}, 400)
    if not data['name'].strip().isalpha() or len(data['name']) > 80:
        return jsonify({'error': 'Invalid name'}, 400)
    if not data['stock'] or not isinstance(data['stock'], int) or data['stock'] < 0 or data['stock'] > 1000:
        return jsonify({'error': 'Invalid stock'}, 400)
    cursor.execute('INSERT INTO reservations (product_id, quantity, request_key, status) VALUES (?, ?, ?, ?)', (data['product_id'], data['quantity'], data['request_key'], 'active'))
    conn.commit()
    cursor.execute('UPDATE products SET stock -= ? WHERE id = ?', (data['stock'], data['product_id']))
    conn.commit()
    return jsonify({'message': 'Reservation created successfully'}, 201)

def cancel_reservation(id):
    cursor.execute('SELECT * FROM reservations WHERE id = ?', (id,))
    reservation = cursor.fetchone()
    if not reservation:
        return jsonify({'error': 'Reservation not found'}, 404)
    cursor.execute('UPDATE reservations SET status = ? WHERE id = ?', (None, id))
    conn.commit()
    cursor.execute('UPDATE products SET stock += ? WHERE id = ?', (reservation['quantity'], id))
    conn.commit()
    return jsonify({'message': 'Reservation cancelled successfully'}, 200)

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=os.environ.get('PORT', 5000), threaded=True)
