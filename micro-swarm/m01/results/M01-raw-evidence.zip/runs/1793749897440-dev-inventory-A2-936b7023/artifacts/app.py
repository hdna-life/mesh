import os
import sqlite3
from flask import Flask, request, jsonify

app = Flask(__name__)

# Database connection settings
DATABASE_PATH = os.environ.get('DATABASE_PATH')
if not DATABASE_PATH:
    raise ValueError("DATABASE_PATH environment variable is not set")

# Initialize database
def init_db():
    conn = sqlite3.connect(DATABASE_PATH)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY,
                sku TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL,
                stock INTEGER NOT NULL
            );''')
    c.execute('''CREATE TABLE IF NOT EXISTS reservations (
                id INTEGER PRIMARY KEY,
                product_id INTEGER NOT NULL,
                quantity INTEGER NOT NULL,
                request_key TEXT NOT NULL,
                status TEXT NOT NULL,
                FOREIGN KEY (product_id) REFERENCES products (id)
            );''')
    conn.commit()

# Define routes
@app.route('/products', methods=['GET'])
def get_products():
    conn = sqlite3.connect(DATABASE_PATH)
    c = conn.cursor()
    c.execute("SELECT * FROM products ORDER BY id ASC")
    products = c.fetchall()
    conn.close()
    return jsonify(products)

@app.route('/products/<int:id>', methods=['GET'])
def get_product(id):
    conn = sqlite3.connect(DATABASE_PATH)
    c = conn.cursor()
    c.execute("SELECT * FROM products WHERE id = ?", (id,))
    product = c.fetchone()
    conn.close()
    if product is None:
        return jsonify({"error": "Product not found"}), 404
    return jsonify(product)

@app.route('/reservations', methods=['GET'])
def get_reservations():
    conn = sqlite3.connect(DATABASE_PATH)
    c = conn.cursor()
    c.execute("SELECT * FROM reservations ORDER BY id ASC")
    reservations = c.fetchall()
    conn.close()
    return jsonify(reservations)

@app.route('/reservations/<int:id>', methods=['GET'])
def get_reservation(id):
    conn = sqlite3.connect(DATABASE_PATH)
    c = conn.cursor()
    c.execute("SELECT * FROM reservations WHERE id = ?", (id,))
    reservation = c.fetchone()
    conn.close()
    if reservation is None:
        return jsonify({"error": "Reservation not found"}), 404
    return jsonify(reservation)

@app.route('/reservations', methods=['POST'])
def create_reservation():
    data = request.get_json()
    if not data:
        return jsonify({"error": "Missing request body"}), 400
    sku = data.get('sku')
    name = data.get('name')
    stock = data.get('stock')
    if not sku or not name or not stock:
        return jsonify({"error": "Missing required fields"}), 400
    if not sku.isalnum():
        return jsonify({"error": "Invalid SKU"}), 400
    if not name.strip().isalpha() or len(name) > 80:
        return jsonify({"error": "Invalid name"}), 400
    if not stock.isdigit() or not 0 <= stock <= 1000:
        return jsonify({"error": "Invalid stock"}), 400
    conn = sqlite3.connect(DATABASE_PATH)
    c = conn.cursor()
    c.execute("INSERT INTO products (sku, name, stock) VALUES (?, ?, ?)", (sku, name, stock))
    product_id = c.lastrowid
    c.execute("INSERT INTO reservations (product_id, quantity, request_key) VALUES (?, ?, ?)", (product_id, data.get('quantity'), request.json.get('request_key')))
    conn.commit()
    conn.close()
    return jsonify({"message": "Reservation created successfully"})

@app.route('/reservations/<int:id>/cancel', methods=['POST'])
def cancel_reservation(id):
    conn = sqlite3.connect(DATABASE_PATH)
    c = conn.cursor()
    c.execute("SELECT * FROM reservations WHERE id = ?", (id,))
    reservation = c.fetchone()
    if reservation is None:
        return jsonify({"error": "Reservation not found"}), 404
    c.execute("UPDATE reservations SET status = ? WHERE id = ?", (0, id))
    conn.commit()
    conn.close()
    return jsonify({"message": "Reservation cancelled successfully"})

if __name__ == '__main__':
    init_db()
    app.run(host='127.0.0.1', port=int(os.environ.get('PORT', 5000)), threaded=True)
